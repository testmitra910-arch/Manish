# TEST MITRA - GitHub APK Build

1. Create a GitHub repository and upload this project.
2. In **Settings → Secrets and variables → Actions → New repository secret**, create:
   - `SUPABASE_URL` = your Supabase Project URL
   - `SUPABASE_ANON_KEY` = your Supabase Publishable key (the app currently names this variable ANON_KEY)
3. Open **Actions → Build TEST MITRA APK → Run workflow**.
4. After the workflow succeeds, open the workflow run and download the artifact **TEST-MITRA-debug-apk**.

Do not commit `.env` or any Supabase secret to the repository.
